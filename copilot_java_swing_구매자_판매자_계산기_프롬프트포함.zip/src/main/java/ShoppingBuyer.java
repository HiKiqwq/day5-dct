import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.Objects;

public class ShoppingBuyer extends JPanel {
    private final ShoppingMallApp.MainFrame mainFrame;
    private final CardLayout contentLayout = new CardLayout();
    private final JPanel contentPanel = new JPanel(contentLayout);
    private final JPanel menuPanel = new JPanel();
    private final SignUpPanel signUpPanel;
    private final MemberDetailPanel memberDetailPanel;
    private final UpdatePanel updatePanel;
    private final WithdrawalPanel withdrawalPanel;
    private final AddressPanel addressPanel;
    private final OrderHistoryPanel orderHistoryPanel;
    private ShoppingMallApp.Member currentMember;

    public ShoppingBuyer(ShoppingMallApp.MainFrame mainFrame) {
        this.mainFrame = mainFrame;
        this.currentMember = ShoppingMallApp.ShoppingData.members.get(0);
        setLayout(new BorderLayout());

        signUpPanel = new SignUpPanel();
        memberDetailPanel = new MemberDetailPanel();
        updatePanel = new UpdatePanel();
        withdrawalPanel = new WithdrawalPanel();
        addressPanel = new AddressPanel();
        orderHistoryPanel = new OrderHistoryPanel();

        contentPanel.add(signUpPanel, "signup");
        contentPanel.add(memberDetailPanel, "detail");
        contentPanel.add(updatePanel, "update");
        contentPanel.add(withdrawalPanel, "withdraw");
        contentPanel.add(addressPanel, "address");
        contentPanel.add(orderHistoryPanel, "orders");

        menuPanel.setLayout(new GridLayout(0, 1, 0, 8));
        menuPanel.setBackground(new Color(245, 247, 250));
        menuPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        addMenuButton("회원가입", "signup");
        addMenuButton("내 정보", "detail");
        addMenuButton("정보 수정", "update");
        addMenuButton("회원 탈퇴", "withdraw");
        addMenuButton("배송지 관리", "address");
        addMenuButton("주문 내역", "orders");
        JButton sellerModeBtn = new JButton("판매자 모드로 전환");
        sellerModeBtn.addActionListener(e -> mainFrame.showSellerView());
        menuPanel.add(sellerModeBtn);

        add(menuPanel, BorderLayout.WEST);
        add(contentPanel, BorderLayout.CENTER);
        showCard("detail");
    }

    private void addMenuButton(String title, String cardName) {
        JButton button = new JButton(title);
        button.addActionListener(e -> showCard(cardName));
        menuPanel.add(button);
    }

    public void showCard(String cardName) {
        contentLayout.show(contentPanel, cardName);
        if (Objects.equals(cardName, "detail")) {
            memberDetailPanel.refresh();
        } else if (Objects.equals(cardName, "address")) {
            addressPanel.refresh();
        } else if (Objects.equals(cardName, "orders")) {
            orderHistoryPanel.refresh();
        } else if (Objects.equals(cardName, "update")) {
            updatePanel.refresh();
        }
    }

    public void setCurrentMember(ShoppingMallApp.Member member) {
        this.currentMember = member;
        memberDetailPanel.refresh();
    }

    private class SignUpPanel extends JPanel {
        private final JTextField idField = new JTextField();
        private final JPasswordField passwordField = new JPasswordField();
        private final JPasswordField confirmField = new JPasswordField();
        private final JTextField nameField = new JTextField();
        private final JTextField emailField = new JTextField();
        private final JTextField phoneField = new JTextField();
        private final JTextField birthField = new JTextField();

        SignUpPanel() {
            setLayout(new BorderLayout());
            JPanel formPanel = new JPanel(new GridBagLayout());
            GridBagConstraints gbc = new GridBagConstraints();
            gbc.insets = new Insets(8, 8, 8, 8);
            gbc.anchor = GridBagConstraints.WEST;
            addField(formPanel, gbc, 0, 0, "아이디");
            addField(formPanel, gbc, 1, 0, idField);
            addField(formPanel, gbc, 0, 1, "비밀번호");
            addField(formPanel, gbc, 1, 1, passwordField);
            addField(formPanel, gbc, 0, 2, "비밀번호 확인");
            addField(formPanel, gbc, 1, 2, confirmField);
            addField(formPanel, gbc, 0, 3, "이름");
            addField(formPanel, gbc, 1, 3, nameField);
            addField(formPanel, gbc, 0, 4, "이메일");
            addField(formPanel, gbc, 1, 4, emailField);
            addField(formPanel, gbc, 0, 5, "전화번호");
            addField(formPanel, gbc, 1, 5, phoneField);
            addField(formPanel, gbc, 0, 6, "생년월일");
            addField(formPanel, gbc, 1, 6, birthField);

            JPanel buttonPanel = new JPanel();
            JButton submitButton = new JButton("가입");
            JButton cancelButton = new JButton("취소");
            submitButton.addActionListener(e -> handleSubmit());
            cancelButton.addActionListener(e -> clearForm());
            buttonPanel.add(submitButton);
            buttonPanel.add(cancelButton);

            add(formPanel, BorderLayout.CENTER);
            add(buttonPanel, BorderLayout.SOUTH);
        }

        private void addField(JPanel panel, GridBagConstraints gbc, int x, int y, String label) {
            gbc.gridx = x;
            gbc.gridy = y;
            panel.add(new JLabel(label), gbc);
        }

        private void addField(JPanel panel, GridBagConstraints gbc, int x, int y, JComponent component) {
            gbc.gridx = x;
            gbc.gridy = y;
            component.setPreferredSize(new Dimension(280, 30));
            panel.add(component, gbc);
        }

        private void handleSubmit() {
            String id = idField.getText().trim();
            String password = new String(passwordField.getPassword());
            String confirm = new String(confirmField.getPassword());
            String name = nameField.getText().trim();
            String email = emailField.getText().trim();
            String phone = phoneField.getText().trim();
            String birth = birthField.getText().trim();
            if (id.isEmpty() || password.isEmpty() || confirm.isEmpty() || name.isEmpty() || email.isEmpty() || phone.isEmpty() || birth.isEmpty()) {
                JOptionPane.showMessageDialog(this, "필수 항목을 모두 입력해 주세요.");
                return;
            }
            if (!password.equals(confirm)) {
                JOptionPane.showMessageDialog(this, "비밀번호가 일치하지 않습니다.");
                return;
            }
            if (!ShoppingMallApp.isValidEmail(email)) {
                JOptionPane.showMessageDialog(this, "이메일 형식이 올바르지 않습니다.");
                return;
            }
            boolean duplicate = ShoppingMallApp.ShoppingData.members.stream().anyMatch(m -> m.id.equalsIgnoreCase(id));
            if (duplicate) {
                JOptionPane.showMessageDialog(this, "이미 사용 중인 아이디입니다.");
                return;
            }
            ShoppingMallApp.Member member = new ShoppingMallApp.Member(id, name, email, phone, birth, "2026-07-08", "2026-07-08", "브론즈", 1000, password);
            ShoppingMallApp.ShoppingData.members.add(0, member);
            currentMember = member;
            JOptionPane.showMessageDialog(this, "회원가입이 완료되었습니다.");
            clearForm();
            showCard("detail");
        }

        private void clearForm() {
            idField.setText("");
            passwordField.setText("");
            confirmField.setText("");
            nameField.setText("");
            emailField.setText("");
            phoneField.setText("");
            birthField.setText("");
        }
    }

    private class MemberDetailPanel extends JPanel {
        private final JLabel idLabel = new JLabel();
        private final JLabel nameLabel = new JLabel();
        private final JLabel emailLabel = new JLabel();
        private final JLabel phoneLabel = new JLabel();
        private final JLabel joinLabel = new JLabel();
        private final JLabel loginLabel = new JLabel();
        private final JLabel gradeLabel = new JLabel();

        MemberDetailPanel() {
            setLayout(new BorderLayout());
            JPanel infoPanel = new JPanel(new GridLayout(0, 2, 10, 10));
            infoPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
            infoPanel.add(new JLabel("아이디"));
            infoPanel.add(idLabel);
            infoPanel.add(new JLabel("이름"));
            infoPanel.add(nameLabel);
            infoPanel.add(new JLabel("이메일"));
            infoPanel.add(emailLabel);
            infoPanel.add(new JLabel("전화번호"));
            infoPanel.add(phoneLabel);
            infoPanel.add(new JLabel("가입일"));
            infoPanel.add(joinLabel);
            infoPanel.add(new JLabel("최근 로그인"));
            infoPanel.add(loginLabel);
            infoPanel.add(new JLabel("등급 / 포인트"));
            infoPanel.add(gradeLabel);

            JPanel buttonPanel = new JPanel();
            JButton updateBtn = new JButton("수정");
            JButton backBtn = new JButton("뒤로가기");
            updateBtn.addActionListener(e -> showCard("update"));
            backBtn.addActionListener(e -> mainFrame.showBuyerView());
            buttonPanel.add(updateBtn);
            buttonPanel.add(backBtn);

            add(infoPanel, BorderLayout.CENTER);
            add(buttonPanel, BorderLayout.SOUTH);
        }

        void refresh() {
            ShoppingMallApp.Member member = currentMember;
            if (member == null) {
                return;
            }
            idLabel.setText(member.id);
            nameLabel.setText(member.name);
            emailLabel.setText(member.email);
            phoneLabel.setText(member.phone);
            joinLabel.setText(member.joinDate);
            loginLabel.setText(member.lastLogin);
            gradeLabel.setText(member.grade + " / " + member.points + "P");
        }
    }

    private class UpdatePanel extends JPanel {
        private final JPasswordField currentPasswordField = new JPasswordField();
        private final JPasswordField newPasswordField = new JPasswordField();
        private final JPasswordField confirmPasswordField = new JPasswordField();
        private final JTextField emailField = new JTextField();
        private final JTextField phoneField = new JTextField();
        private final JTextField addressField = new JTextField();

        UpdatePanel() {
            setLayout(new BorderLayout());
            JPanel formPanel = new JPanel(new GridBagLayout());
            GridBagConstraints gbc = new GridBagConstraints();
            gbc.insets = new Insets(8, 8, 8, 8);
            gbc.anchor = GridBagConstraints.WEST;
            addField(formPanel, gbc, 0, 0, "현재 비밀번호");
            addField(formPanel, gbc, 1, 0, currentPasswordField);
            addField(formPanel, gbc, 0, 1, "새 비밀번호");
            addField(formPanel, gbc, 1, 1, newPasswordField);
            addField(formPanel, gbc, 0, 2, "새 비밀번호 확인");
            addField(formPanel, gbc, 1, 2, confirmPasswordField);
            addField(formPanel, gbc, 0, 3, "이메일");
            addField(formPanel, gbc, 1, 3, emailField);
            addField(formPanel, gbc, 0, 4, "전화번호");
            addField(formPanel, gbc, 1, 4, phoneField);
            addField(formPanel, gbc, 0, 5, "주소");
            addField(formPanel, gbc, 1, 5, addressField);

            JPanel buttonPanel = new JPanel();
            JButton saveBtn = new JButton("저장");
            JButton cancelBtn = new JButton("취소");
            saveBtn.addActionListener(e -> handleSave());
            cancelBtn.addActionListener(e -> showCard("detail"));
            buttonPanel.add(saveBtn);
            buttonPanel.add(cancelBtn);

            add(formPanel, BorderLayout.CENTER);
            add(buttonPanel, BorderLayout.SOUTH);
        }

        private void addField(JPanel panel, GridBagConstraints gbc, int x, int y, String label) {
            gbc.gridx = x;
            gbc.gridy = y;
            panel.add(new JLabel(label), gbc);
        }

        private void addField(JPanel panel, GridBagConstraints gbc, int x, int y, JComponent component) {
            gbc.gridx = x;
            gbc.gridy = y;
            component.setPreferredSize(new Dimension(280, 30));
            panel.add(component, gbc);
        }

        void refresh() {
            if (currentMember != null) {
                emailField.setText(currentMember.email);
                phoneField.setText(currentMember.phone);
                addressField.setText(currentMember.address);
            }
        }

        private void handleSave() {
            if (currentMember == null) {
                return;
            }
            String currentPassword = new String(currentPasswordField.getPassword());
            String newPassword = new String(newPasswordField.getPassword());
            String confirmPassword = new String(confirmPasswordField.getPassword());
            if (!currentPassword.equals(currentMember.password)) {
                JOptionPane.showMessageDialog(this, "현재 비밀번호가 일치하지 않습니다.");
                return;
            }
            if (!newPassword.isEmpty() && !newPassword.equals(confirmPassword)) {
                JOptionPane.showMessageDialog(this, "새 비밀번호가 일치하지 않습니다.");
                return;
            }
            if (!newPassword.isEmpty()) {
                currentMember.password = newPassword;
            }
            currentMember.email = emailField.getText().trim();
            currentMember.phone = phoneField.getText().trim();
            currentMember.address = addressField.getText().trim();
            JOptionPane.showMessageDialog(this, "정보가 수정되었습니다.");
            showCard("detail");
        }
    }

    private class WithdrawalPanel extends JPanel {
        private final JCheckBox confirmBox = new JCheckBox("탈퇴에 동의합니다");
        private final JPasswordField passwordField = new JPasswordField();
        private final JComboBox<String> reasonBox = new JComboBox<>(new String[]{"서비스 불만족", "사용 빈도 낮음", "개인정보 우려", "기타"});
        private final JTextArea detailArea = new JTextArea();

        WithdrawalPanel() {
            setLayout(new BorderLayout());
            JPanel formPanel = new JPanel(new GridLayout(0, 1, 6, 6));
            formPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
            formPanel.add(confirmBox);
            formPanel.add(new JLabel("비밀번호 확인"));
            formPanel.add(passwordField);
            formPanel.add(new JLabel("탈퇴 사유"));
            formPanel.add(reasonBox);
            formPanel.add(new JLabel("상세 사유"));
            formPanel.add(new JScrollPane(detailArea));

            JPanel buttonPanel = new JPanel();
            JButton withdrawBtn = new JButton("탈퇴 진행");
            JButton cancelBtn = new JButton("취소");
            withdrawBtn.addActionListener(e -> handleWithdraw());
            cancelBtn.addActionListener(e -> showCard("detail"));
            buttonPanel.add(withdrawBtn);
            buttonPanel.add(cancelBtn);

            add(formPanel, BorderLayout.CENTER);
            add(buttonPanel, BorderLayout.SOUTH);
        }

        private void handleWithdraw() {
            if (!confirmBox.isSelected()) {
                JOptionPane.showMessageDialog(this, "탈퇴 동의가 필요합니다.");
                return;
            }
            if (currentMember == null) {
                return;
            }
            String password = new String(passwordField.getPassword());
            if (!password.equals(currentMember.password)) {
                JOptionPane.showMessageDialog(this, "비밀번호가 올바르지 않습니다.");
                return;
            }
            ShoppingMallApp.ShoppingData.members.remove(currentMember);
            currentMember = ShoppingMallApp.ShoppingData.members.isEmpty() ? null : ShoppingMallApp.ShoppingData.members.get(0);
            JOptionPane.showMessageDialog(this, "회원 탈퇴가 처리되었습니다.");
            showCard("signup");
        }
    }

    private class AddressPanel extends JPanel {
        private final JTable table;
        private final DefaultTableModel tableModel;

        AddressPanel() {
            setLayout(new BorderLayout());
            String[] columns = {"배송지명", "받는사람", "주소", "연락처", "기본배송지"};
            tableModel = new DefaultTableModel(columns, 0) {
                @Override
                public boolean isCellEditable(int row, int column) {
                    return false;
                }
            };
            table = new JTable(tableModel);
            JPanel buttonPanel = new JPanel();
            JButton addBtn = new JButton("추가");
            JButton editBtn = new JButton("수정");
            JButton deleteBtn = new JButton("삭제");
            JButton defaultBtn = new JButton("기본 배송지 설정");
            addBtn.addActionListener(e -> openAddressDialog(null));
            editBtn.addActionListener(e -> {
                int row = table.getSelectedRow();
                if (row >= 0) {
                    ShoppingMallApp.Address address = ShoppingMallApp.ShoppingData.addresses.get(row);
                    openAddressDialog(address);
                }
            });
            deleteBtn.addActionListener(e -> {
                int row = table.getSelectedRow();
                if (row >= 0) {
                    ShoppingMallApp.ShoppingData.addresses.remove(row);
                    refresh();
                }
            });
            defaultBtn.addActionListener(e -> {
                int row = table.getSelectedRow();
                if (row >= 0) {
                    for (ShoppingMallApp.Address address : ShoppingMallApp.ShoppingData.addresses) {
                        address.defaultAddress = false;
                    }
                    ShoppingMallApp.ShoppingData.addresses.get(row).defaultAddress = true;
                    refresh();
                }
            });
            buttonPanel.add(addBtn);
            buttonPanel.add(editBtn);
            buttonPanel.add(deleteBtn);
            buttonPanel.add(defaultBtn);
            add(new JScrollPane(table), BorderLayout.CENTER);
            add(buttonPanel, BorderLayout.SOUTH);
        }

        void refresh() {
            tableModel.setRowCount(0);
            for (ShoppingMallApp.Address address : ShoppingMallApp.ShoppingData.addresses) {
                tableModel.addRow(new Object[]{address.name, address.recipient, address.address, address.contact, address.defaultAddress ? "예" : "아니오"});
            }
        }

        private void openAddressDialog(ShoppingMallApp.Address editing) {
            JDialog dialog = new JDialog((Frame) SwingUtilities.getWindowAncestor(this), "배송지 관리", true);
            dialog.setLayout(new GridBagLayout());
            GridBagConstraints gbc = new GridBagConstraints();
            gbc.insets = new Insets(6, 6, 6, 6);
            gbc.anchor = GridBagConstraints.WEST;
            JTextField nameField = new JTextField(editing == null ? "" : editing.name);
            JTextField recipientField = new JTextField(editing == null ? "" : editing.recipient);
            JTextField addressField = new JTextField(editing == null ? "" : editing.address);
            JTextField contactField = new JTextField(editing == null ? "" : editing.contact);
            JCheckBox defaultBox = new JCheckBox("기본 배송지로 설정", editing != null && editing.defaultAddress);
            addField(dialog, gbc, 0, 0, "배송지명");
            addField(dialog, gbc, 1, 0, nameField);
            addField(dialog, gbc, 0, 1, "받는 사람");
            addField(dialog, gbc, 1, 1, recipientField);
            addField(dialog, gbc, 0, 2, "주소");
            addField(dialog, gbc, 1, 2, addressField);
            addField(dialog, gbc, 0, 3, "연락처");
            addField(dialog, gbc, 1, 3, contactField);
            gbc.gridx = 0;
            gbc.gridy = 4;
            gbc.gridwidth = 2;
            dialog.add(defaultBox, gbc);
            JButton saveBtn = new JButton("저장");
            saveBtn.addActionListener(e -> {
                if (editing == null) {
                    ShoppingMallApp.ShoppingData.addresses.add(new ShoppingMallApp.Address(nameField.getText().trim(), recipientField.getText().trim(), addressField.getText().trim(), contactField.getText().trim(), defaultBox.isSelected()));
                } else {
                    editing.name = nameField.getText().trim();
                    editing.recipient = recipientField.getText().trim();
                    editing.address = addressField.getText().trim();
                    editing.contact = contactField.getText().trim();
                    editing.defaultAddress = defaultBox.isSelected();
                }
                refresh();
                dialog.dispose();
            });
            gbc.gridy = 5;
            dialog.add(saveBtn, gbc);
            dialog.pack();
            dialog.setLocationRelativeTo(this);
            dialog.setVisible(true);
        }

        private void addField(Container container, GridBagConstraints gbc, int x, int y, String label) {
            gbc.gridx = x;
            gbc.gridy = y;
            container.add(new JLabel(label), gbc);
        }

        private void addField(Container container, GridBagConstraints gbc, int x, int y, JComponent component) {
            gbc.gridx = x;
            gbc.gridy = y;
            component.setPreferredSize(new Dimension(240, 28));
            container.add(component, gbc);
        }
    }

    private class OrderHistoryPanel extends JPanel {
        private final JTable table;
        private final DefaultTableModel tableModel;

        OrderHistoryPanel() {
            setLayout(new BorderLayout());
            String[] columns = {"주문번호", "주문일", "상품명", "수량", "금액", "배송상태"};
            tableModel = new DefaultTableModel(columns, 0) {
                @Override
                public boolean isCellEditable(int row, int column) {
                    return false;
                }
            };
            table = new JTable(tableModel);
            add(new JScrollPane(table), BorderLayout.CENTER);
        }

        void refresh() {
            tableModel.setRowCount(0);
            for (ShoppingMallApp.Order order : ShoppingMallApp.ShoppingData.orders) {
                tableModel.addRow(new Object[]{order.id, order.orderDate, order.productName, order.quantity, order.amount, order.status});
            }
        }
    }
}
