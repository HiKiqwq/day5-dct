import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class ShoppingSeller extends JPanel {
    private final CardLayout contentLayout = new CardLayout();
    private final JPanel contentPanel = new JPanel(contentLayout);
    private final JPanel menuPanel = new JPanel();

    public ShoppingSeller(ShoppingMallApp.MainFrame mainFrame) {
        setLayout(new BorderLayout());
        contentPanel.add(new DashboardPanel(), "dashboard");
        contentPanel.add(new ProductPanel(), "product");
        contentPanel.add(new OrderPanel(), "order");
        contentPanel.add(new ShippingPanel(), "shipping");
        contentPanel.add(new InventoryPanel(), "inventory");
        contentPanel.add(new SalesPanel(), "sales");
        contentPanel.add(new ReviewPanel(), "review");
        contentPanel.add(new NoticePanel(), "notice");
        contentPanel.add(new MemberManagementPanel(), "member");

        menuPanel.setLayout(new GridLayout(0, 1, 0, 8));
        menuPanel.setBackground(new Color(244, 247, 250));
        menuPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        addMenuButton("대시보드", "dashboard");
        addMenuButton("상품관리", "product");
        addMenuButton("주문관리", "order");
        addMenuButton("배송관리", "shipping");
        addMenuButton("재고관리", "inventory");
        addMenuButton("매출관리", "sales");
        addMenuButton("리뷰관리", "review");
        addMenuButton("공지사항", "notice");
        addMenuButton("회원관리", "member");
        JButton buyerModeBtn = new JButton("구매자 모드로 전환");
        buyerModeBtn.addActionListener(e -> mainFrame.showBuyerView());
        menuPanel.add(buyerModeBtn);

        add(menuPanel, BorderLayout.WEST);
        add(contentPanel, BorderLayout.CENTER);
        showCard("dashboard");
    }

    private void addMenuButton(String title, String cardName) {
        JButton button = new JButton(title);
        button.addActionListener(e -> showCard(cardName));
        menuPanel.add(button);
    }

    public void showCard(String cardName) {
        contentLayout.show(contentPanel, cardName);
    }

    private static class DashboardPanel extends JPanel {
        DashboardPanel() {
            setLayout(new BorderLayout());
            JPanel summaryPanel = new JPanel(new GridLayout(1, 4, 10, 10));
            summaryPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
            summaryPanel.add(createSummaryCard("오늘 주문", "12건"));
            summaryPanel.add(createSummaryCard("총 매출", "1,250,000원"));
            summaryPanel.add(createSummaryCard("신규 회원", "8명"));
            summaryPanel.add(createSummaryCard("평균 주문", "104,000원"));

            JPanel centerPanel = new JPanel(new GridLayout(1, 2, 10, 10));
            centerPanel.setBorder(BorderFactory.createEmptyBorder(10, 20, 20, 20));
            JTextArea reviewArea = new JTextArea("최근 리뷰\n- 배송이 빠르고 만족도가 높습니다.\n- 제품 품질이 좋아 재구매 예정입니다.");
            reviewArea.setEditable(false);
            centerPanel.add(new JScrollPane(reviewArea));
            JList<String> orders = new JList<>(new String[]{"신규 주문 #1001", "신규 주문 #1002", "재입고 요청 #1003"});
            centerPanel.add(new JScrollPane(orders));

            add(summaryPanel, BorderLayout.NORTH);
            add(centerPanel, BorderLayout.CENTER);
        }

        private JPanel createSummaryCard(String title, String value) {
            JPanel panel = new JPanel();
            panel.setBackground(new Color(235, 245, 255));
            panel.setBorder(BorderFactory.createLineBorder(Color.LIGHT_GRAY));
            panel.setLayout(new BorderLayout());
            JLabel titleLabel = new JLabel(title, SwingConstants.CENTER);
            JLabel valueLabel = new JLabel(value, SwingConstants.CENTER);
            valueLabel.setFont(new Font("Malgun Gothic", Font.BOLD, 18));
            panel.add(titleLabel, BorderLayout.NORTH);
            panel.add(valueLabel, BorderLayout.CENTER);
            return panel;
        }
    }

    private static class ProductPanel extends JPanel {
        private final JTable table;
        private final DefaultTableModel tableModel;

        ProductPanel() {
            setLayout(new BorderLayout());
            String[] columns = {"상품코드", "상품명", "카테고리", "가격", "재고", "판매상태"};
            tableModel = new DefaultTableModel(columns, 0) {
                @Override
                public boolean isCellEditable(int row, int column) {
                    return false;
                }
            };
            table = new JTable(tableModel);
            JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
            JTextField keywordField = new JTextField(12);
            JComboBox<String> categoryBox = new JComboBox<>(new String[]{"전체", "의류", "전자기기", "식품", "도서", "가구", "기타"});
            JButton searchBtn = new JButton("검색");
            JButton addBtn = new JButton("등록");
            JButton deleteBtn = new JButton("삭제");
            topPanel.add(new JLabel("검색어"));
            topPanel.add(keywordField);
            topPanel.add(new JLabel("카테고리"));
            topPanel.add(categoryBox);
            topPanel.add(searchBtn);
            topPanel.add(addBtn);
            topPanel.add(deleteBtn);
            addBtn.addActionListener(e -> openProductDialog(null));
            deleteBtn.addActionListener(e -> {
                int row = table.getSelectedRow();
                if (row >= 0) {
                    tableModel.removeRow(row);
                }
            });
            refresh();
            add(topPanel, BorderLayout.NORTH);
            add(new JScrollPane(table), BorderLayout.CENTER);
        }

        void refresh() {
            tableModel.setRowCount(0);
            for (ShoppingMallApp.Product product : ShoppingMallApp.ShoppingData.products) {
                tableModel.addRow(new Object[]{product.code, product.name, product.category, product.price, product.stock, product.status});
            }
        }

        private void openProductDialog(ShoppingMallApp.Product editing) {
            JDialog dialog = new JDialog((Frame) SwingUtilities.getWindowAncestor(this), "상품 등록", true);
            dialog.setLayout(new GridBagLayout());
            GridBagConstraints gbc = new GridBagConstraints();
            gbc.insets = new Insets(6, 6, 6, 6);
            gbc.anchor = GridBagConstraints.WEST;
            JTextField codeField = new JTextField(editing == null ? "" : editing.code);
            JTextField nameField = new JTextField(editing == null ? "" : editing.name);
            JTextField priceField = new JTextField(editing == null ? "" : String.valueOf(editing.price));
            JTextField stockField = new JTextField(editing == null ? "" : String.valueOf(editing.stock));
            JComboBox<String> categoryBox = new JComboBox<>(new String[]{"의류", "전자기기", "식품", "도서", "가구", "기타"});
            categoryBox.setSelectedItem(editing == null ? "기타" : editing.category);
            JComboBox<String> statusBox = new JComboBox<>(new String[]{"판매중", "품절", "숨김"});
            statusBox.setSelectedItem(editing == null ? "판매중" : editing.status);
            addField(dialog, gbc, 0, 0, "상품코드");
            addField(dialog, gbc, 1, 0, codeField);
            addField(dialog, gbc, 0, 1, "상품명");
            addField(dialog, gbc, 1, 1, nameField);
            addField(dialog, gbc, 0, 2, "카테고리");
            addField(dialog, gbc, 1, 2, categoryBox);
            addField(dialog, gbc, 0, 3, "가격");
            addField(dialog, gbc, 1, 3, priceField);
            addField(dialog, gbc, 0, 4, "재고");
            addField(dialog, gbc, 1, 4, stockField);
            addField(dialog, gbc, 0, 5, "상태");
            addField(dialog, gbc, 1, 5, statusBox);
            JButton saveBtn = new JButton("저장");
            saveBtn.addActionListener(e -> {
                ShoppingMallApp.Product product = new ShoppingMallApp.Product(codeField.getText().trim(), nameField.getText().trim(), categoryBox.getSelectedItem().toString(), statusBox.getSelectedItem().toString(), Double.parseDouble(priceField.getText()), Integer.parseInt(stockField.getText()));
                ShoppingMallApp.ShoppingData.products.add(product);
                refresh();
                dialog.dispose();
            });
            gbc.gridy = 6;
            dialog.add(saveBtn, gbc);
            dialog.pack();
            dialog.setLocationRelativeTo(this);
            dialog.setVisible(true);
        }

        private void addField(Container container, GridBagConstraints gbc, int x, int y, String label) {
            gbc.gridx = x;
            gbc.gridy = y;
            container.add(new JLabel(label), gbc);
        }

        private void addField(Container container, GridBagConstraints gbc, int x, int y, JComponent component) {
            gbc.gridx = x;
            gbc.gridy = y;
            component.setPreferredSize(new Dimension(240, 28));
            container.add(component, gbc);
        }
    }

    private static class OrderPanel extends JPanel {
        OrderPanel() {
            setLayout(new BorderLayout());
            String[] columns = {"주문번호", "고객명", "상품명", "금액", "상태"};
            DefaultTableModel tableModel = new DefaultTableModel(columns, 0) {
                @Override
                public boolean isCellEditable(int row, int column) {
                    return false;
                }
            };
            JTable table = new JTable(tableModel);
            for (ShoppingMallApp.Order order : ShoppingMallApp.ShoppingData.orders) {
                tableModel.addRow(new Object[]{order.id, order.customerName, order.productName, order.amount, order.status});
            }
            add(new JScrollPane(table), BorderLayout.CENTER);
        }
    }

    private static class ShippingPanel extends JPanel {
        ShippingPanel() {
            setLayout(new BorderLayout());
            String[] columns = {"주문번호", "고객명", "상품명", "배송지", "상태"};
            DefaultTableModel tableModel = new DefaultTableModel(columns, 0) {
                @Override
                public boolean isCellEditable(int row, int column) {
                    return false;
                }
            };
            JTable table = new JTable(tableModel);
            for (ShoppingMallApp.Order order : ShoppingMallApp.ShoppingData.orders) {
                tableModel.addRow(new Object[]{order.id, order.customerName, order.productName, "서울시 강남구", order.status});
            }
            add(new JScrollPane(table), BorderLayout.CENTER);
        }
    }

    private static class InventoryPanel extends JPanel {
        InventoryPanel() {
            setLayout(new BorderLayout());
            String[] columns = {"상품코드", "상품명", "현재재고", "안전재고", "상태"};
            DefaultTableModel tableModel = new DefaultTableModel(columns, 0) {
                @Override
                public boolean isCellEditable(int row, int column) {
                    return false;
                }
            };
            JTable table = new JTable(tableModel);
            for (ShoppingMallApp.Product product : ShoppingMallApp.ShoppingData.products) {
                String status = product.stock <= 5 ? "부족" : "충분";
                tableModel.addRow(new Object[]{product.code, product.name, product.stock, 10, status});
            }
            add(new JScrollPane(table), BorderLayout.CENTER);
        }
    }

    private static class SalesPanel extends JPanel {
        SalesPanel() {
            setLayout(new BorderLayout());
            JLabel label = new JLabel("월별 매출 그래프", SwingConstants.CENTER);
            label.setFont(new Font("Malgun Gothic", Font.BOLD, 18));
            add(label, BorderLayout.NORTH);
            add(new JPanel() {
                @Override
                protected void paintComponent(Graphics g) {
                    super.paintComponent(g);
                    Graphics2D g2 = (Graphics2D) g.create();
                    g2.setColor(Color.BLUE);
                    int[] values = {100, 220, 180, 260, 320, 410};
                    int x = 40;
                    int yBase = 220;
                    for (int i = 0; i < values.length; i++) {
                        int height = values[i] / 2;
                        int xPos = x + i * 60;
                        g2.fillRect(xPos, yBase - height, 40, height);
                    }
                    g2.dispose();
                }
            }, BorderLayout.CENTER);
        }
    }

    private static class ReviewPanel extends JPanel {
        ReviewPanel() {
            setLayout(new BorderLayout());
            String[] columns = {"리뷰번호", "상품명", "평점", "작성자", "상태"};
            DefaultTableModel tableModel = new DefaultTableModel(columns, 0) {
                @Override
                public boolean isCellEditable(int row, int column) {
                    return false;
                }
            };
            JTable table = new JTable(tableModel);
            for (ShoppingMallApp.Review review : ShoppingMallApp.ShoppingData.reviews) {
                tableModel.addRow(new Object[]{review.id, review.productName, review.rating, review.author, review.status});
            }
            add(new JScrollPane(table), BorderLayout.CENTER);
        }
    }

    private static class NoticePanel extends JPanel {
        NoticePanel() {
            setLayout(new BorderLayout());
            JPanel formPanel = new JPanel(new GridLayout(0, 2, 8, 8));
            formPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
            JTextField titleField = new JTextField();
            JComboBox<String> levelBox = new JComboBox<>(new String[]{"일반", "중요", "긴급"});
            JTextArea contentArea = new JTextArea(8, 20);
            JButton saveBtn = new JButton("저장");
            saveBtn.addActionListener(e -> JOptionPane.showMessageDialog(this, "공지사항이 등록되었습니다."));
            formPanel.add(new JLabel("제목"));
            formPanel.add(titleField);
            formPanel.add(new JLabel("중요도"));
            formPanel.add(levelBox);
            formPanel.add(new JLabel("내용"));
            formPanel.add(new JScrollPane(contentArea));
            formPanel.add(new JLabel());
            formPanel.add(saveBtn);
            add(formPanel, BorderLayout.CENTER);
        }
    }

    private static class MemberManagementPanel extends JPanel {
        MemberManagementPanel() {
            setLayout(new BorderLayout());
            String[] columns = {"아이디", "이름", "이메일", "등급", "상태"};
            DefaultTableModel tableModel = new DefaultTableModel(columns, 0) {
                @Override
                public boolean isCellEditable(int row, int column) {
                    return false;
                }
            };
            JTable table = new JTable(tableModel);
            for (ShoppingMallApp.Member member : ShoppingMallApp.ShoppingData.members) {
                tableModel.addRow(new Object[]{member.id, member.name, member.email, member.grade, "정상"});
            }
            add(new JScrollPane(table), BorderLayout.CENTER);
        }
    }
}
