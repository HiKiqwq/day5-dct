import javax.swing.*;
import java.awt.*;

public class Cal extends JDialog {
    private final JTextField display = new JTextField("0");
    private double firstValue = 0;
    private String operator = "";
    private boolean newInput = true;

    public Cal(Frame owner) {
        super(owner, "계산기", true);
        setLayout(new BorderLayout());
        display.setEditable(false);
        display.setHorizontalAlignment(JTextField.RIGHT);
        display.setFont(new Font("Malgun Gothic", Font.BOLD, 24));
        add(display, BorderLayout.NORTH);

        JPanel grid = new JPanel(new GridLayout(4, 4, 6, 6));
        String[] labels = {"7", "8", "9", "/", "4", "5", "6", "*", "1", "2", "3", "-", "0", ".", "=", "+"};
        for (String label : labels) {
            JButton button = new JButton(label);
            button.addActionListener(e -> handleButton(label));
            grid.add(button);
        }
        add(grid, BorderLayout.CENTER);
        pack();
        setLocationRelativeTo(owner);
    }

    private void handleButton(String label) {
        if (label.matches("[0-9.]")) {
            if (newInput) {
                display.setText(label);
                newInput = false;
            } else {
                display.setText(display.getText() + label);
            }
        } else if (label.matches("[+\\-*/]")) {
            firstValue = Double.parseDouble(display.getText());
            operator = label;
            newInput = true;
        } else if ("=".equals(label)) {
            double secondValue = Double.parseDouble(display.getText());
            double result = calculate(firstValue, secondValue, operator);
            display.setText(String.valueOf(result));
            newInput = true;
        }
    }

    private double calculate(double first, double second, String op) {
        return switch (op) {
            case "+" -> first + second;
            case "-" -> first - second;
            case "*" -> first * second;
            case "/" -> second == 0 ? 0 : first / second;
            default -> second;
        };
    }
}
