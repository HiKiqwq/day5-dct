import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

public class ShoppingMallApp {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            MainFrame frame = new MainFrame();
            frame.setVisible(true);
        });
    }

    public static class MainFrame extends JFrame {
        private final CardLayout cardLayout = new CardLayout();
        private final JPanel mainPanel = new JPanel(cardLayout);
        private final ShoppingBuyer buyerPanel;
        private final ShoppingSeller sellerPanel;

        public MainFrame() {
            setTitle("Shopping Mall Management System");
            setSize(1280, 840);
            setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            setLocationRelativeTo(null);

            buyerPanel = new ShoppingBuyer(this);
            sellerPanel = new ShoppingSeller(this);

            JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
            topPanel.setBackground(new Color(34, 45, 60));
            JButton buyerBtn = new JButton("구매자 모드");
            JButton sellerBtn = new JButton("판매자 모드");
            JButton calculatorBtn = new JButton("계산기");
            buyerBtn.addActionListener(e -> showBuyerView());
            sellerBtn.addActionListener(e -> showSellerView());
            calculatorBtn.addActionListener(e -> openCalculator());
            topPanel.add(buyerBtn);
            topPanel.add(sellerBtn);
            topPanel.add(calculatorBtn);

            mainPanel.add(buyerPanel, "buyer");
            mainPanel.add(sellerPanel, "seller");

            setJMenuBar(createMenuBar());
            setLayout(new BorderLayout());
            add(topPanel, BorderLayout.NORTH);
            add(mainPanel, BorderLayout.CENTER);

            showBuyerView();
        }

        private JMenuBar createMenuBar() {
            JMenuBar menuBar = new JMenuBar();
            JMenu toolsMenu = new JMenu("도구");
            JMenuItem calculatorItem = new JMenuItem("계산기");
            calculatorItem.addActionListener(e -> openCalculator());
            toolsMenu.add(calculatorItem);
            menuBar.add(toolsMenu);
            return menuBar;
        }

        public void openCalculator() {
            Cal dialog = new Cal(this);
            dialog.setVisible(true);
        }

        public void showBuyerView() {
            cardLayout.show(mainPanel, "buyer");
        }

        public void showSellerView() {
            cardLayout.show(mainPanel, "seller");
        }
    }

    public static class ShoppingData {
        public static final List<Member> members = new ArrayList<>();
        public static final List<Address> addresses = new ArrayList<>();
        public static final List<Product> products = new ArrayList<>();
        public static final List<Order> orders = new ArrayList<>();
        public static final List<Review> reviews = new ArrayList<>();

        static {
            members.add(new Member("buyer01", "홍길동", "buyer01@example.com", "010-1111-2222", "1990-01-01", "2026-01-01", "2026-07-08", "골드", 3200, "1234"));
            members.add(new Member("seller01", "김판매", "seller01@example.com", "010-3333-4444", "1988-02-02", "2025-12-01", "2026-07-07", "플래티넘", 8000, "5678"));
            addresses.add(new Address("집", "홍길동", "서울시 강남구 테헤란로 1", "010-1111-2222", true));
            addresses.add(new Address("회사", "홍길동", "서울시 서초구 반포대로 2", "010-1111-2222", false));
            products.add(new Product("P001", "무선 이어폰", "전자기기", "판매중", 149000, 20));
            products.add(new Product("P002", "프리미엄 셔츠", "의류", "판매중", 59000, 8));
            products.add(new Product("P003", "아이스크림", "식품", "품절", 4800, 0));
            orders.add(new Order(1001, "2026-07-01", "홍길동", "무선 이어폰", 1, 149000, "배송중"));
            orders.add(new Order(1002, "2026-07-03", "홍길동", "프리미엄 셔츠", 2, 118000, "결제완료"));
            reviews.add(new Review(1, "무선 이어폰", 5, "홍길동", "답변완료"));
            reviews.add(new Review(2, "프리미엄 셔츠", 4, "김판매", "미답변"));
        }
    }

    public static class Member {
        public String id;
        public String name;
        public String email;
        public String phone;
        public String birthDate;
        public String joinDate;
        public String lastLogin;
        public String grade;
        public int points;
        public String password;
        public String address;

        public Member(String id, String name, String email, String phone, String birthDate, String joinDate, String lastLogin, String grade, int points, String password) {
            this.id = id;
            this.name = name;
            this.email = email;
            this.phone = phone;
            this.birthDate = birthDate;
            this.joinDate = joinDate;
            this.lastLogin = lastLogin;
            this.grade = grade;
            this.points = points;
            this.password = password;
            this.address = "서울시 강남구";
        }
    }

    public static class Address {
        public String name;
        public String recipient;
        public String address;
        public String contact;
        public boolean defaultAddress;

        public Address(String name, String recipient, String address, String contact, boolean defaultAddress) {
            this.name = name;
            this.recipient = recipient;
            this.address = address;
            this.contact = contact;
            this.defaultAddress = defaultAddress;
        }
    }

    public static class Product {
        public String code;
        public String name;
        public String category;
        public double price;
        public int stock;
        public String status;

        public Product(String code, String name, String category, String status, double price, int stock) {
            this.code = code;
            this.name = name;
            this.category = category;
            this.price = price;
            this.stock = stock;
            this.status = status;
        }
    }

    public static class Order {
        public int id;
        public String orderDate;
        public String customerName;
        public String productName;
        public int quantity;
        public double amount;
        public String status;

        public Order(int id, String orderDate, String customerName, String productName, int quantity, double amount, String status) {
            this.id = id;
            this.orderDate = orderDate;
            this.customerName = customerName;
            this.productName = productName;
            this.quantity = quantity;
            this.amount = amount;
            this.status = status;
        }
    }

    public static class Review {
        public int id;
        public String productName;
        public int rating;
        public String author;
        public String status;

        public Review(int id, String productName, int rating, String author, String status) {
            this.id = id;
            this.productName = productName;
            this.rating = rating;
            this.author = author;
            this.status = status;
        }
    }

    public static boolean isValidEmail(String email) {
        String regex = "^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,6}$";
        return Pattern.matches(regex, email);
    }
}
